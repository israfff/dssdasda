from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram import Dispatcher, Bot
import logging

storage = MemoryStorage()

bot = Bot(token='2018028472:AAFhr_7KF8AZIaqRsHkGclLxlnD-YH-2Nb8', parse_mode='HTML')
dp = Dispatcher(bot, storage=storage)
logging.basicConfig(level=logging.INFO)