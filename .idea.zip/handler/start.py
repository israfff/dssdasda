from aiogram.types import CallbackQuery

from database import new_user, checking_to_info, verif, add_50_rub, add_user_referal
from keyboard.inline import start, get_info
from loader import dp, bot
from aiogram import types

gif = 'BQACAgIAAxkBAAICXGFJ-RpLU1VrHsbHPQn6enrAu--TAAKeDgAC5URRSlwZn_8H7_-GIQQ'

@dp.message_handler(commands='start')
async def low_menu(message: types.Message):
    user_id = message.from_user.id
    new_user(user_id=user_id)
    check = checking_to_info(user_id=user_id)
    if check[0] == 0:
        if message.get_args():
            if str(message.from_user.id) == str(message.get_args()):
                await message.answer('Нельзя переходить по своей реферальной ссылки')
            else:
                add_50_rub(user_id=int(message.get_args()))
                add_user_referal(user_id=int(message.get_args()))
        await bot.send_document(chat_id=message.from_user.id,
                                document=gif, caption=
                                f'👋🏻 Здравствуй, {message.from_user.first_name}!\n'
                                f'🔥Мы соединяем авторов контента в тик ток, и наших пользователей.'
                                f' За поднятие рейтинга вы получаете деньги\n'
                                f'👀 За каждый просмотр в TikTok мы платим 10 руб., а за каждый комментарий по 20 руб.\n'
                                f'☑️ Жми "Ознакомлен", чтобы уже начать зарабатывать.',
                                reply_markup=get_info)
    else:
        await message.answer(f'Выберите пункт меню⤵\n',
                             reply_markup=start)


@dp.callback_query_handler(text='es')
async def oznakomlen(call: CallbackQuery):
    user_id = call.from_user.id
    verif(user_id=user_id)
    await call.message.delete()
    await call.message.answer(f'Выберите пункт меню⤵',
                              reply_markup=start)

