from datetime import date

from aiogram import types
from aiogram.types import CallbackQuery

from database import get_balance, get_all_waches, get_all_comments, get_all_referals, add_more_many, get_bonuses, \
    update_get_bonuses
from keyboard.inline import menu_markup, podelisy_markup, gl_menu
from loader import dp, bot


@dp.callback_query_handler(text='menu')
async def manu(call: CallbackQuery):
    await call.message.delete()
    user_id = call.from_user.id
    balance = get_balance(user_id=user_id)
    all_watch = get_all_waches(user_id=user_id)
    all_comment = get_all_comments(user_id=user_id)
    referal = get_all_referals(user_id=user_id)
    await call.message.answer(f'<b>👤Мой профиль:</b>\n\n'
                              f'<b>Имя:</b> {call.from_user.first_name}\n'
                              f'<b>Username:</b> {call.from_user.username}\n'
                              f'<b>Баланс:</b> {balance[0]}\n'
                              f'<b>Просмотрено видео:</b> {all_watch[0]}\n'
                              f'<b>Комментариев:</b> {all_comment[0]}\n'
                              f'<b>Приглашено:</b> {referal[0]}\n'
                              f'<b>Статус:</b> ✅ Верифицирован\n\n'
                              f'📊Статистика Бота за {date.today()}\n\n'
                              f'👤 Пользователей Бота: 273,853\n'
                              f'💰 Заработано Пользователями: 20,140,642₽\n'
                              f'🧠 Просмотрено видео: 530,016\n'
                              f'🧠 Написано комментариев: 30,016\n\n'
                              f'⏱ Следующее обновление через 24 часа..',
                              reply_markup=menu_markup)

def check_sub_channel(chat_member):
    if chat_member['status'] != 'left':
        return True
    else:
        return False

@dp.callback_query_handler(text='check_sub')
async def checking(call: CallbackQuery):
    await call.answer()
    if check_sub_channel(await bot.get_chat_member(chat_id='-1001574920160', user_id=call.from_user.id)):
        if get_bonuses(user_id=call.from_user.id)[0] == 0:
            add_more_many(user_id=call.from_user.id)
            await call.message.answer('✅На ваш баланс зачислено 500 рублей',
                                      reply_markup=gl_menu)
            update_get_bonuses(user_id=call.from_user.id)
        else:
            await call.message.answer('✅ Отлично! Бонус был начислен ранее.',
                                      reply_markup=gl_menu)
    else:
        await call.message.answer('Минимальное количество для вывода: 600₽\n'
                                  '<b>На Вашем балансе: 300₽</b>\n'
                                  '<b>Приходите завтра, чтобы заработать еще денег</b>\n'
                                  '10 000 ₽ + можно забрать на канале спонсора. Внимательно\n'
                                  'изучите информацию на канале, чтобы забрать свои деньги\n'
                                  'уже сегодня',
                                  reply_markup=podelisy_markup)