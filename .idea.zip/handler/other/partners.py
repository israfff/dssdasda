from keyboard.inline import markup_partner
from loader import dp, bot
from aiogram.types import CallbackQuery
from aiogram import types

@dp.callback_query_handler(text='partners')
async def part(call: CallbackQuery):
    await call.message.delete()
    await call.message.answer(f'<b>💼 Получайте бонусы за приглашённых друзей</b>\n\n'
                              f'➡️ Ваша пригласительная ссылка:\n'
                              f'https://t.me/TikTokRise_Bot?start={call.from_user.id}\n\n'
                              f'✔️ 50 руб. за каждого приглашенного Вами пользователя.\n'
                              f'➕ Приглашено человек: 0',
                              reply_markup=markup_partner)