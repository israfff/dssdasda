from aiogram.dispatcher import FSMContext

from database import get_balance, minus_balance
from keyboard.defualt import nazad
from keyboard.inline import markup_withdraw, subb_chanel, start, podelisy_markup, gl_menu
from loader import dp, bot
from aiogram.types import CallbackQuery
from aiogram import types

from state.states import with_phone

gif_draw = 'BQACAgIAAxkBAAIECmFLLCoZVxhNDaXKEMt03fxlAAFwxAACiREAAu8dWEr980RA2J3RnCEE'

@dp.message_handler(text='Назад', state='*')
async def back(message: types.Message, state: FSMContext):
    await state.finish()
    await message.delete()
    await message.answer(f'Выберите пункт меню⤵',
                         reply_markup=start)

@dp.callback_query_handler(text='withdraw')
async def with_draw(call: CallbackQuery):
    await call.message.delete()
    balance = get_balance(user_id=call.from_user.id)
    await bot.send_document(chat_id=call.from_user.id,
                            document=gif_draw,
                            caption=f'💰 Баланс: <b>{balance[0]}₽</b>\n\n'
                                    f'Вы можете вывести средства, либо заработать\n'
                                    f'дополнительно денег перед выводом',
                            reply_markup=markup_withdraw)

@dp.callback_query_handler(text='phone')
async def with_phones(call: CallbackQuery):
    await call.message.delete()
    await call.message.answer('Введите ваши реквизиты',
                              reply_markup=nazad)
    await with_phone.get_phone.set()

@dp.message_handler(state=with_phone.get_phone)
async def get_phone(message: types.Message, state: FSMContext):
    await message.answer(f'Укажите сумму списания 👇')
    await with_phone.get_summ.set()

@dp.message_handler(state=with_phone.get_summ)
async def get_summ(message: types.Message, state: FSMContext):
    try:
        if int(message.text):
            await state.update_data(count=message.text)
            await message.answer('Для того, чтобы пройти верификацию, подпишитесь на канал\n'
                                 'партнеров и просмотрите ближайшие 15 постов!',
                                 reply_markup=subb_chanel)
            await state.reset_state(with_data=False)
    except Exception:
        await message.answer('Введите корректную сумму списания. Напишите в ответном\n'
                             'сообщении целое число\n\n'
                             'Намремер: 100, 200, 500, 1000')
        await with_phone.get_summ.set()

#

@dp.callback_query_handler(text='qiwi')
async def with_qiwi(call: CallbackQuery):
    await call.message.delete()
    await call.message.answer('Введите ваши реквизиты',
                              reply_markup=nazad)
    await with_phone.get_phone.set()

@dp.message_handler(state=with_phone.get_phone)
async def get_phone(message: types.Message, state: FSMContext):
    await message.answer(f'Укажите сумму списания 👇')
    await with_phone.get_summ.set()

@dp.message_handler(state=with_phone.get_summ)
async def get_summ(message: types.Message, state: FSMContext):
    try:
        if int(message.text):
            await state.update_data(count=message.text)
            await message.answer('Для того, чтобы пройти верификацию, подпишитесь на канал\n'
                                 'партнеров и просмотрите ближайшие 15 постов!',
                                 reply_markup=subb_chanel)
            await state.reset_state(with_data=False)
    except Exception:
        await message.answer('Введите корректную сумму списания. Напишите в ответном\n'
                             'сообщении целое число\n\n'
                             'Намремер: 100, 200, 500, 1000')
        await with_phone.get_summ.set()

#

@dp.callback_query_handler(text='yoomany')
async def with_yoomaney(call: CallbackQuery):
    await call.message.delete()
    await call.message.answer('Введите ваши реквизиты',
                              reply_markup=nazad)
    await with_phone.get_phone.set()

@dp.message_handler(state=with_phone.get_phone)
async def get_phone(message: types.Message, state: FSMContext):
    await message.answer(f'Укажите сумму списания 👇')
    await with_phone.get_summ.set()

@dp.message_handler(state=with_phone.get_summ)
async def get_summ(message: types.Message, state: FSMContext):
    try:
        if int(message.text):
            await state.update_data(count=message.text)
            await message.answer('Для того, чтобы пройти верификацию, подпишитесь на канал\n'
                                 'партнеров и просмотрите ближайшие 15 постов!',
                                 reply_markup=subb_chanel)
            await state.reset_state(with_data=False)
    except Exception:
        await message.answer('Введите корректную сумму списания. Напишите в ответном\n'
                             'сообщении целое число\n\n'
                             'Намремер: 100, 200, 500, 1000')
        await with_phone.get_summ.set()

#

@dp.callback_query_handler(text='cards')
async def with_cards(call: CallbackQuery):
    await call.message.delete()
    await call.message.answer('Введите ваши реквизиты',
                              reply_markup=nazad)
    await with_phone.get_phone.set()

@dp.message_handler(state=with_phone.get_phone)
async def get_phone(message: types.Message, state: FSMContext):
    await message.answer(f'Укажите сумму списания 👇')
    await with_phone.get_summ.set()

@dp.message_handler(state=with_phone.get_summ)
async def get_summ(message: types.Message, state: FSMContext):
    try:
        if int(message.text):
            await state.update_data(count=message.text)
            await message.answer('Для того, чтобы пройти верификацию, подпишитесь на канал\n'
                                 'партнеров и просмотрите ближайшие 15 постов!',
                                 reply_markup=subb_chanel)
            await state.reset_state(with_data=False)
    except Exception:
        await message.answer('Введите корректную сумму списания. Напишите в ответном\n'
                             'сообщении целое число\n\n'
                             'Намремер: 100, 200, 500, 1000')
        await with_phone.get_summ.set()

#

@dp.callback_query_handler(text='check_sub1')
async def vivod(call: CallbackQuery, state: FSMContext):
    await call.answer()
    if get_balance(user_id=call.from_user.id)[0] < 600:
        await call.message.answer(f'Минимальное количество для вывода: 600₽\n'
                                  f'<b>На Вашем балансе: {get_balance(user_id=call.from_user.id)[0]}₽</b>\n'
                                  f'<b>Приходите завтра, чтобы заработать еще денег</b>\n'
                                  f'10 000 ₽ + можно забрать на канале спонсора. Внимательно\n'
                                  f'изучите информацию на канале, чтобы забрать свои деньги \n'
                                  f'уже сегодня', reply_markup=podelisy_markup)
    else:
        data = await state.get_data()
        count = data.get('count')
        minus_balance(count=count, user_id=call.from_user.id)
        await call.message.answer('✅ Ваш запрос передан на обработку в платежный шлюз..\n'
                                  'Обработка платежа занимает до 3-х рабочих дней!',
                                  reply_markup=gl_menu)

