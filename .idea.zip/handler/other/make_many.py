import asyncio

from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from database import get_balance, get_prosmotry, add_prosmotry, add_many, add_other_prosmotry, get_comments, \
    add_many_20, add_comments, add_other_comments
from keyboard.inline import for_cash, start, control, cancel, control_com
from loader import dp, bot
from aiogram import types
import time

from state.states import videos, new_state

photo = 'AgACAgIAAxkBAAMIYUineGVFPzIkuSy9p6liiiMRRXIAAjq3MRvlRElK1VkEC1dyki8BAAMCAAN5AAMgBA'
ttv1 = 'BAACAgIAAxkBAAMYYUipvM4v9uQeQ7IIs6ljzRMkT4YAAlkRAALlRElKdApfM5cu9LggBA'
ttv2 = 'BAACAgIAAxkBAAM9YUi3pLMYZKqMIhavD16cSOejUpkAAsARAALlRElKKMS5GENHzZwgBA'
ttv3 = 'BAACAgIAAxkBAANHYUi4Fxf3U07cMIcN41hVGgjh2GoAAsIRAALlRElKrg8akD3W6SYgBA'
ttv4 = 'BAACAgIAAxkBAANJYUi4U6YBK5xwML6hCVTAo4AWWWwAAsMRAALlRElKYX6P-tg_iCEgBA'
ttv5 = 'BAACAgIAAxkBAANNYUi4nwZf7-nK_YW9Esp_XB3IB50AAsYRAALlRElKTMtmCN_Wow4gBA'
ttv6 = 'BAACAgIAAxkBAANPYUi41w1nNs5TYtRIjkNJGtmzYvUAAscRAALlRElK0ZtNURQU0dggBA'
ttv7 = 'BAACAgIAAxkBAANRYUi5IEGyaDRT3GDEOonwT7bveXYAAskRAALlRElKs4mp6AZef7ogBA'
ttv8 = 'BAACAgIAAxkBAANTYUi5TzxFh5XaXyA4rEOlSHFQDlgAAs8RAALlRElKgvkTxQMetZEgBA'
ttv9 = 'BAACAgIAAxkBAANVYUi5fKbs3HC-TG9KP3y4ZuGlJs4AAtERAALlRElK-lSkmycqPrEgBA'
ttv10 = 'BAACAgIAAxkBAANXYUi50KabZFjWYoegX9hTAsfW22QAAtURAALlRElKXdR_jZoRuvMgBA'
ttv11 = 'BAACAgIAAxkBAANZYUi6MXuGapA2hRgNzpjPWLMnzDUAAtgRAALlRElKPQcpQeHo194gBA'
ttv12 = 'BAACAgIAAxkBAANbYUi6ky1j1EZnZEqrnwUiJx4JkiAAAtoRAALlRElKdXb9yry5ROogBA'
ttv13 = 'BAACAgIAAxkBAANdYUi64p9CGgqmwWTNirzqdT1s79IAAt0RAALlRElKPlYZVXWUprYgBA'
ttv14 = 'BAACAgIAAxkBAANfYUi7V3_P5jUkg74CtgABwbgHo-g8AALgEQAC5URJSi-8HwkfHHKCIAQ'
ttv15 = 'BAACAgIAAxkBAANhYUi7k0j6mypEq92t_B32m6q-yq4AAuIRAALlRElKQcAyg6nkPw8gBA'
ttv16 = 'BAACAgIAAxkBAANjYUi78uBnSeRnEMieFP9jXTbYDWQAAuMRAALlRElKBBuLUsKwJLsgBA'
ttv17 = 'BAACAgIAAxkBAANlYUi8NQYUhRw9wTXEZT9t4ymUpscAAuURAALlRElKFjSdELDv7icgBA'
ttv18 = 'BAACAgIAAxkBAANnYUi8Z2BnQSRuqSENWv5VKR2SwooAAucRAALlRElK7ayccUo2VDsgBA'
ttv19 = 'BAACAgIAAxkBAAIGA2FLTfovrAMemwyf21nbZKY754ZHAAKvEgAC7x1YSq2hanZ0LLoKIQQ'
ttv20 = 'BAACAgIAAxkBAAIGBWFLTkNyy3hJq-gIvSRReR-58_u5AAKwEgAC7x1YSqQlTws2lZUOIQQ'

cmtv1 = 'BAACAgIAAxkBAAIGB2FLT6JGiDz26OkisWD1LH7UKtHtAAK3EgAC7x1YSi5yLDXdH7wHIQQ'
cmtv2 = 'BAACAgIAAxkBAAIGCWFLT8s8zJ7i22euwlGSVmcAAZ9CLgACuhIAAu8dWEo58ciX9wqmJyEE'
cmtv3 = 'BAACAgIAAxkBAAIGC2FLUCMSpRuWemFMpfx5ZGCr2zOVAAK8EgAC7x1YSn1WETqQRsmIIQQ'
cmtv4 = 'BAACAgIAAxkBAAIGDWFLUOUI5Hp3M66AAAFtPOpBbgQZLAACxRIAAu8dWEqpHNCOgkT_RSEE'

@dp.callback_query_handler(state='*', text='back')
async def del_pred_message(call: CallbackQuery, state: FSMContext):
    await state.finish()
    await call.message.delete()
    await call.message.answer(f'Выберите пункт меню⤵',
                              reply_markup=start)

@dp.callback_query_handler(text='start_cash')
async def make_cash(call: CallbackQuery, state: FSMContext):
    await call.message.delete()
    await bot.send_photo(chat_id=call.from_user.id,
                         photo=photo,
                         caption='Выберите способ заработка 👇',
                         reply_markup=for_cash)

@dp.callback_query_handler(text='watching')
async def watch_tt(call: CallbackQuery, state: FSMContext):
    await call.message.delete()
    user_id = call.from_user.id
    prosm = get_prosmotry(user_id=user_id)
    bal = get_balance(user_id=user_id)
    add_prosmotry(user_id=user_id)
    add_many(user_id=user_id)
    add_other_prosmotry(user_id=user_id)
    global msg
    global msg1
    global msg2
    global msg3
    global msg4
    global msg5
    global msg6
    global msg7
    global msg8
    global msg9
    global msg10
    global msg11
    global msg12
    global msg13
    global msg14
    global msg15
    global msg16
    global msg17
    global msg18
    global msg19
    if prosm[0] == 0:
        msg = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv1,
                             reply_markup=control)
    elif prosm[0] == 1:
        msg1 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv2,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg.message_id)
    elif prosm[0] == 2:
        msg2 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv3,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg1.message_id)
    elif prosm[0] == 3:
        msg3 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv4,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg2.message_id)
    elif prosm[0] == 4:
        msg4 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv5,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg3.message_id)
    elif prosm[0] == 5:
        msg5 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv6,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg4.message_id)
    elif prosm[0] == 6:
        msg6 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv7,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg5.message_id)
    elif prosm[0] == 7:
        msg7 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv8,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg6.message_id)
    elif prosm[0] == 8:
        msg8 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv9,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg7.message_id)
    elif prosm[0] == 9:
        msg9 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv10,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg8.message_id)
    elif prosm[0] == 10:
        msg10 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv11,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg9.message_id)
    elif prosm[0] == 11:
        msg11 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv12,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg10.message_id)
    elif prosm[0] == 12:
        msg12 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv13,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg11.message_id)
    elif prosm[0] == 13:
        msg13 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv14,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg12.message_id)
    elif prosm[0] == 14:
        msg14 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv15,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg13.message_id)
    elif prosm[0] == 15:
        msg15 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv16,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg14.message_id)
    elif prosm[0] == 16:
        msg16 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv17,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg15.message_id)
    elif prosm[0] == 17:
        msg17 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv18,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg16.message_id)
    elif prosm[0] == 18:
        msg18 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv19,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg17.message_id)
    elif prosm[0] == 19:
        msg19 = await call.message.answer('👀<b>Заработок с просмотра:</b> 10₽\n'
                                        f'<b>👏🏻 Выполнено:</b> {prosm[0]} из 20\n'
                                        f'<b>💰 Ваш баланс:</b> {bal[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv20,
                             reply_markup=control)
        await bot.delete_message(chat_id=user_id, message_id=msg18.message_id)
    elif prosm[0] > 19:
        text = '''
😔К сожалению, лимит платных просмотров за последние 24 часа исчерпан. Возвращайтесь завтра!

😉НО Вы так же можете получить оплату за комментарии…

🤑 Не забудьте заказать выплату денежных средств в кнопке "💳 Вывести"
            '''
        await call.message.answer(text,
                                  reply_markup=cancel)

@dp.callback_query_handler(text='comments')
async def com_cash(call: CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    com = get_comments(user_id=user_id)[0]
    balance = get_balance(user_id=user_id)
    add_many_20(user_id=user_id)
    add_comments(user_id=user_id)
    add_other_comments(user_id=user_id)
    global mesg1
    global mesg2
    global mesg3
    global mesg4
    global mesg5
    global mesg6
    global mesg7
    global mesg8
    global mesg9
    global mesg10
    global com1
    global com2
    global com3
    global com4
    global com5
    global com6
    global com7
    global com8
    global com9
    global com10
    if com == 0:
        mesg1 = await call.message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=cmtv1,
                             reply_markup=control_com)
        com1 = await call.message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 1:
        mesg2 = await call.message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=cmtv2,
                             reply_markup=control_com)
        com2 = await call.message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 2:
        mesg3 = await call.message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv4,
                             reply_markup=control_com)
        com3 = await call.message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 3:
        mesg4 = await call.message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=cmtv4,
                             reply_markup=control_com)
        com4 = await call.message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 4:
        mesg5 = await call.message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv12,
                             reply_markup=control_com)
        com5 = await call.message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 5:
        mesg6 = await call.message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv14,
                             reply_markup=control_com)
        com6 = await call.message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 6:
        mesg7 = await call.message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv16,
                             reply_markup=control_com)
        com7 = await call.message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 7:
        mesg8 = await call.message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv18,
                             reply_markup=control_com)
        com8 = await call.message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 8:
        mesg9 = await call.message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv3,
                             reply_markup=control_com)
        com1 = await call.message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 9:
        mesg10 = await call.message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=call.from_user.id,
                             video=ttv13,
                             reply_markup=control_com)
        com10 = await call.message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com > 9:
        await call.message.delete()
        text = '''
😔К сожалению, лимит платных просмотров за последние 24 часа исчерпан. Возвращайтесь завтра!

😉НО Вы так же можете получить оплату за комментарии…

🤑 Не забудьте заказать выплату денежных средств в кнопке "💳 Вывести"
                    '''
        await call.message.answer(text,
                                  reply_markup=cancel)

@dp.message_handler(state=new_state.comment)
async def new_comment(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    com = get_comments(user_id=user_id)[0]
    balance = get_balance(user_id=user_id)
    add_many_20(user_id=user_id)
    add_comments(user_id=user_id)
    add_other_comments(user_id=user_id)
    global mesg1
    global mesg2
    global mesg3
    global mesg4
    global mesg5
    global mesg6
    global mesg7
    global mesg8
    global mesg9
    global mesg10
    global com1
    global com2
    global com3
    global com4
    global com5
    global com6
    global com7
    global com8
    global com9
    global com10
    if com == 0:
        mesg1 = await message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=message.from_user.id,
                             video=cmtv1,
                             reply_markup=control_com)
        com1 = await message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 1:
        mesg2 = await message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=message.from_user.id,
                             video=cmtv2,
                             reply_markup=control_com)
        com2 = await message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 2:
        mesg3 = await message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=message.from_user.id,
                             video=ttv4,
                             reply_markup=control_com)
        com3 = await message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 3:
        mesg4 = await message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=message.from_user.id,
                             video=cmtv4,
                             reply_markup=control_com)
        com4 = await message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 4:
        mesg5 = await message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                          f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                          f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=message.from_user.id,
                             video=ttv12,
                             reply_markup=control_com)
        com5 = await message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 5:
        mesg6 = await message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                     f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                     f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=message.from_user.id,
                             video=ttv14,
                             reply_markup=control_com)
        com6 = await message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 6:
        mesg7 = await message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                     f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                     f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=message.from_user.id,
                             video=ttv16,
                             reply_markup=control_com)
        com7 = await message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 7:
        mesg8 = await message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                     f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                     f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=message.from_user.id,
                             video=ttv18,
                             reply_markup=control_com)
        com8 = await message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 8:
        mesg9 = await message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                     f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                     f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=message.from_user.id,
                             video=ttv3,
                             reply_markup=control_com)
        com1 = await message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com == 9:
        mesg10 = await message.answer('👀<b>Заработок с просмотра:</b> 20₽\n'
                                      f'<b>👏🏻 Выполнено:</b> {com} из 10\n'
                                      f'<b>💰 Ваш баланс:</b> {balance[0]}₽')
        await bot.send_video(chat_id=message.from_user.id,
                             video=ttv13,
                             reply_markup=control_com)
        com10 = await message.answer('Напишите комментарий👇')
        await new_state.comment.set()
    if com > 9:
        await message.delete()
        text = '''
😔К сожалению, лимит платных просмотров за последние 24 часа исчерпан. Возвращайтесь завтра!

😉НО Вы так же можете получить оплату за комментарии…

🤑 Не забудьте заказать выплату денежных средств в кнопке "💳 Вывести"
                    '''
        await message.answer(text,
                             reply_markup=cancel)
        await state.finish()

@dp.callback_query_handler(state='*', text='back')
async def del_pred_message(call: CallbackQuery, state: FSMContext):
    await state.finish()
    await call.message.delete()
    await call.message.answer(f'Выберите пункт меню⤵',
                              reply_markup=start)