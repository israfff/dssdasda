from keyboard.inline import more_many_markup
from loader import dp, bot
from aiogram.types import CallbackQuery
from aiogram import types

@dp.callback_query_handler(text='more_many')
async def mores_manyes(call: CallbackQuery):
    await call.message.delete()
    await call.message.answer('👉 Подпишитесь на канал спонсора, и посмотрите последние\n'
                              'посты, после чего нажмите кнопку "<b>💰 Получить бонус</b>". Вам\n'
                              'будет начислено 500 рублей!\n\n'
                              'https://t.me/joinchat/mpWf-GNJws8zYTQy\n\n'
                              'Благодаря спонсорам, платформа продолжает\n'
                              'функционировать, и развиваться\n\n'
                              '<b>❗️ Внимание:</b> если вы отпишитесь от канала спонсора, вы\n'
                              'будете заблокированы в нашей системе <b>TikTok Pay</b> на всех\n'
                              'устройствах!',
                              reply_markup=more_many_markup)