from .start import dp
from .other.make_many import dp
from .other.profil import dp
from .other.witdraw import dp
from .other.partners import dp
from .other.more_many import dp

__all__ = ['dp']