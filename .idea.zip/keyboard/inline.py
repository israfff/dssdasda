from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

start = InlineKeyboardMarkup(row_width=1,
                             inline_keyboard=[
                                 [
                                     InlineKeyboardButton(text='🧑🏻‍💻Начать зарабатывать',
                                                          callback_data='start_cash')
                                 ],
                                 [
                                     InlineKeyboardButton(text='👤Профиль',
                                                          callback_data='menu')
                                 ],
                                 [
                                     InlineKeyboardButton(text='💳Вывести',
                                                          callback_data='withdraw'),
                                     InlineKeyboardButton(text='💼Партнёрам',
                                                          callback_data='partners')
                                 ],
                                 [
                                     InlineKeyboardButton(text='💰Больше денег',
                                                          callback_data='more_many')
                                 ]
                             ])

for_cash = InlineKeyboardMarkup(row_width=1,
                                inline_keyboard=[
                                    [
                                        InlineKeyboardButton(text='Просматривать TikTok',
                                                             callback_data='watching')
                                    ],
                                    [
                                        InlineKeyboardButton(text='Комментировать',
                                                             callback_data='comments')
                                    ],
                                    [
                                        InlineKeyboardButton(text='Назад',
                                                             callback_data='back')
                                    ]
                                ])

control = InlineKeyboardMarkup(row_width=1,
                               inline_keyboard=[
                                   [
                                       InlineKeyboardButton(text='✅Просмотренно',
                                                            callback_data='watching')
                                   ],
                                   [
                                       InlineKeyboardButton(text='✋Закончить',
                                                            callback_data='back')
                                   ]
                               ])

get_info = InlineKeyboardMarkup(row_width=1,
                                inline_keyboard=[
                                    [
                                        InlineKeyboardButton(text='👌Ознакомлен',
                                                             callback_data='es')
                                    ]
                                ])

cancel = InlineKeyboardMarkup(row_width=1,
                              inline_keyboard=[
                                  [
                                      InlineKeyboardButton(text='Назад',
                                                           callback_data='back')
                                  ]
                              ])

menu_markup = InlineKeyboardMarkup(row_width=1,
                                   inline_keyboard=[
                                       [
                                           InlineKeyboardButton(text='Назад',
                                                                callback_data='back')
                                       ],
                                       [
                                           InlineKeyboardButton(text='🧑🏻‍💻Начать зарабатывать',
                                                                callback_data='start_cash')
                                       ],
                                       [
                                           InlineKeyboardButton(text='💰Больше денег',
                                                                callback_data='more_many')
                                       ]
                                   ])

markup_withdraw = InlineKeyboardMarkup(row_width=1,
                                       inline_keyboard=[
                                           [
                                               InlineKeyboardButton(text='📱Телефон',
                                                                    callback_data='phone'),
                                               InlineKeyboardButton(text='🥝QIWI',
                                                                    callback_data='qiwi')
                                           ],
                                           [
                                               InlineKeyboardButton(text='📒Юmoney',
                                                                    callback_data='yoomany'),
                                               InlineKeyboardButton(text='💳Карта',
                                                                    callback_data='cards')
                                           ],
                                           [
                                               InlineKeyboardButton(text='Назад',
                                                                    callback_data='back')
                                           ]

                                       ])

subb_chanel = InlineKeyboardMarkup(row_width=1,
                                   inline_keyboard=[
                                       [
                                           InlineKeyboardButton(text='📲Перейти в канал',
                                                                url='https://t.me/joinchat/mpWf-GNJws8zYTQy')
                                       ],
                                       [
                                           InlineKeyboardButton(text='☑Проверить подписку',
                                                                callback_data='check_sub1')
                                       ]
                                   ])

markup_partner = InlineKeyboardMarkup(row_width=1,
                                      inline_keyboard=[
                                          [
                                              InlineKeyboardButton(text='Поделится с другом',
                                                                   switch_inline_query='Подпишись')
                                          ],
                                          [
                                              InlineKeyboardButton(text='🧑🏻‍💻Начать зарабатывать',
                                                                   callback_data='start_cash')
                                          ],
                                          [
                                              InlineKeyboardButton(text='💰Больше денег',
                                                                   callback_data='more_many')
                                          ],
                                          [
                                              InlineKeyboardButton(text='Главное меню',
                                                                   callback_data='back')
                                          ]
                                      ])

more_many_markup = InlineKeyboardMarkup(row_width=1,
                                        inline_keyboard=[
                                            [
                                                InlineKeyboardButton(text='📲Перейти в канал',
                                                                     url='https://t.me/joinchat/mpWf-GNJws8zYTQy')
                                            ],
                                            [
                                                InlineKeyboardButton(text='☑Проверить подписку',
                                                                     callback_data='check_sub')
                                            ],
                                            [
                                                InlineKeyboardButton(text='Назад',
                                                                     callback_data='back')
                                            ]
                                        ])

podelisy_markup = InlineKeyboardMarkup(row_width=1,
                                       inline_keyboard=[
                                           [
                                               InlineKeyboardButton(text='Забрать 10 000руб',
                                                                    url='https://t.me/joinchat/mpWf-GNJws8zYTQy')
                                           ]
                                       ])

gl_menu = InlineKeyboardMarkup(row_width=1,
                               inline_keyboard=[
                                   [
                                       InlineKeyboardButton(text='Главное меню',
                                                            callback_data='back')
                                   ]
                               ])

control_com = InlineKeyboardMarkup(row_width=1,
                               inline_keyboard=[
                                   [
                                       InlineKeyboardButton(text='✋Закончить',
                                                            callback_data='back')
                                   ]
                               ])