from aiogram.dispatcher.filters.state import StatesGroup, State


class videos(StatesGroup):
    one = State()
    two = State()

class with_phone(StatesGroup):
    get_phone = State()
    get_summ = State()

class new_state(StatesGroup):
    comment = State()